package com.example.StartBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StartBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
